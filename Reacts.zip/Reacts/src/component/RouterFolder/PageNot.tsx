

export default function PageNot() {
  return (
    <div className='h-screen w-screen flex text-[40px] text-black'>404 Not Found</div>
  )
}
